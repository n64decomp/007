GoldenEye Text Economizer
+-+-+-+-+-+-+-+-+-+-+-+-+

  This text economizer accepts one of GoldenEye's text binaries and strips it down as much as possible.  In particular, it removes the NULLs word-aligning the text entries as well as combining certain partially-indentical entries.

+_+

Usage:
  All parameters are optional, but valid commands for each are given here.  Dashes (-) or slashes (/) may be used before all command line options.

Economizer.exe <filename.bin> -O<filename.bin> -L<filename.txt> -E<#> -?
  filename.bin
	Optional input filename
  -Ofilename.bin
	Optional output filename
  -Lfilename.txt
	Optional error log filename
  -E#
	Sets number of entries when autodetection fails, ie. the first entry does not point to the first string in the binary
  -H or -?
	Displays a short help with these command line options

@_@

  Source is provided in the source folder.  Feel free to recode it as you see fit.  

-Zoinkity	(nefariousdogooder@yahoo.com)


