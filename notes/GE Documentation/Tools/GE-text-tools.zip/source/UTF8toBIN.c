#include <stdio.h>
#include <string.h>
#include <stdlib.h>


/*if you aren't targtting an Intel system, set to 0!*/
#define SWAPO     1
#define DEBUGGERY 0     /*general debug messages*/
#define UTF_CODE  0    /*allows you to see the 2-byte UTF code used for lookup*/
#define LOOKSEE   0    /*lets you see the characters in the string as they are output*/
/*reads in UTF-8 script, pumps out tlb+bin*/
  
/*flag byte values*/
#define LINE     1
#define TABS     2
#define USERNUM  3
#define NOISY    4
#define T_OFF    7
#define LARGE    8
#define FIXED    0x10
#define HEX      0x20


/*standard 32bit byteswapping*/
unsigned long byteswap(unsigned long w)
{if(SWAPO) return (w >> 24) | ((w >> 8) & 0x0000ff00) | ((w << 8) & 0x00ff0000) | (w << 24);
 return w;}    

/*standard 16bit byteswapping*/
unsigned short int shortswap(unsigned short int w)
{if(SWAPO) return (w >> 8) | (w << 8);
 return w;}


/*displays errors for command types
  pauses if flag>0, kills if =2*/
int erratta(int x,int flag)
{switch(x){case -1: fprintf(stderr,"\nunable to create table for language file."); break;
           case 0:  fprintf(stderr,"\nunrecognised text character\tskipping"); break;
           case 1: fprintf(stderr,"\nimproper!\tUnknown \"\\\" code.  Write \"\\\\\" to display \"\\\"."); break;
/*           case 1: fprintf(stderr,"\nimproper!\t[]"); break;
           case 1: fprintf(stderr,"\nimproper!\t[]"); break;*/
           }

if(flag>0) {fprintf(stderr,"\nPress -enter- to %s",x==2 ? "continue":"quit"); getchar();}
if(flag==2) exit(x);
return 1;}


/*convert strings to binary - in theory...*/
unsigned long UTF8(unsigned char *in,FILE *tbl,FILE *sample,unsigned long num,FILE *out,char flag)
{unsigned long x,y;
unsigned short z;
unsigned char buf[20];

memset(buf,0,20);

for(x=0;x<num;x++)
    {/*retrieve offset to next entry in samples*/
     y=x<<2;
     fseek(tbl,y,SEEK_SET);
     fread(&y,4,1,tbl);
     /*get the sample to do comparison*/
     fseek(sample,y,SEEK_SET);
     fgets(buf,20,sample);
     /*do comparison and stuff*/
     if(strncmp(in,buf,3)) continue;
       z=0x8080;
       if(flag&LARGE) z|=0x4000;
       z|=x%0x80;
       y=x/0x80;
       y=y<<8;
       z|=y;
       /*byteswap and write to file*/
       z=shortswap(z);
       fwrite(&z,2,1,out);
       break;
     }
if(x>=num) erratta(0,1);

return 2;}


/*this indexes the entries in the text language source files
  returns number of entries, and more importantly puts them in a file provided
  text has to be in text mode, list in binary*/
long jubilee(FILE *text, FILE *list)
{unsigned long x=3,y=0;
 char buffer[20];
 
 fseek(list,0,SEEK_SET);
 do{fseek(text,x,SEEK_SET);
    fgets(buffer,20,text);
    fwrite(&x,4,1,list);
    if(!buffer) break;
    y++;
    x=ftell(text);
    }while(!feof(text));
 
 return y;}

/*the head honcho
  opt holds options:
      1     use line# to set line #s
      2     tabs detected (line numbers present)
      4     noisy
      */
int main(int argc, char *argv[])
{char buf[0x10000],sample[5];    /*buffer is overkill. take that overruns!*/
FILE *txt,*bin,*Ltbl,*Stbl,*Ssource,*Lsource;

unsigned long in=0,pos=0,entry=0,strpos=0,y=0,Snum=0,Lnum=0;     /*pos in infile, pos in bin, cur in tbl*/
unsigned short z=0;
unsigned char x,opt=5;

for(x=1;x<argc;x++)
    {if(argv[x][0]=='-' || argv[x][0]=='/')
      {switch(argv[x][1])
             {case 'N': case 'n': opt^=LINE;  break;
              case 'Q': case 'q': opt^=NOISY;  break;
              case 'L': case 'l': Snum=x; break;
              case 'H': case 'h': case '?':
                  printf("\nConverts UTF-8 text file to GoldenEye binary file");
                  printf("\n\t/N or -N\tignore line numbers - entries in series");
                  printf("\n\t/Q or -Q\tdon't complain if file lacks BOM");
                  printf("\n  /L or -lname\t+\tallows you to name the language files to be used");
                  printf("\n\t/H, /?, -H, or -?\tdisplay this help message");
                  printf("\npress enter to quit"); getchar(); return 0;
              }    
      }
    else y=x;
    }

/*find the table files*/
chdir(dirname(argv[0]));   /*theoretically returns program's directory*/
/*create table for 8xxx text entries*/
if(Snum) strcpy(buf,argv[Snum]+2);
   else strcpy(buf,"japanese.txt");
if(DEBUGGERY) Stbl=fopen("smallJtable.bin", "wb+");
   else Stbl=tmpfile();
if(!Stbl) erratta(-1,2);
while (!(Ssource = fopen(buf, "rt"))) {
	printf("\nWhat's the path to the file \"japanese.txt\"? ");
	strcpy(buf,"\0");	
	gets(buf);
    }
Snum=jubilee(Ssource,Stbl);

/*create table for Cxxx text entries*/
if(strrchr(buf,'.')) strcpy(strrchr(buf,'.'), "large.txt");
   else strcat(buf,"large");
if(DEBUGGERY) Ltbl=fopen("largeJtable.bin", "wb+");
   else Ltbl=tmpfile();
if(!Ltbl) erratta(-1,2);
while (!(Lsource = fopen(buf, "rt"))) {
	printf("\nWhat's the path to the file \"japaneselarge.txt\"? ");
	strcpy(buf,"\0");	
	gets(buf);
    }
Lnum=jubilee(Lsource,Ltbl);


/*open input and output files*/
if(y) strcpy(buf,argv[y]);
else  strcpy(buf,"\0");
while (!(txt = fopen(buf, "rb"))) {
	printf("\nUTF-8 text file? ");
	strcpy(buf,"\0");
	gets(buf);
    }

    if(strrchr(buf,'.')) strcpy(strrchr(buf,'.'), ".bin");
    else strcat(buf,".bin");
while (!(bin = fopen(buf, "wb+"))) {
	printf("\noutput binary? ");
	strcpy(buf,"\0");	
	gets(buf);
    }

/*Confirm if the file has a BOM (a sort of 3-byte header)
  it should read EF BB BF.  Otherwise, prompt abort or assume valid UTF-8 no BOM*/
if(opt&NOISY) printf("\nTesting for BOM...");
x=fgetc(txt);
if(x==0xEF) in=3;
else if(opt&NOISY) {printf("\n\aThis file doesn't have a UTF-8 BOM.\nIf it is straight ANSI text or a UTF-8 file that doesn't have a BOM, it will still work.\n\nType 'Y' to continue anyway, or any other phrase to quit.");
               x=getchar();
               if(islower(x)) x=toupper(x);
               if(x!='Y') return 1;
               }

/*test if line numbers, or more importantly tabs, are present*/
if(opt&NOISY) printf("\nDetermining if line numbers present...");
fseek(txt,0,SEEK_SET);
fread(buf,1,20,txt);
for(x=0;x<20;x++)
   {if(buf[x]==0x09)
      {opt|=TABS;
       break;}
    }

/*if you're using the line numbers, extra fun!
  This allocates the offset table at the beginning
  yes, this really does require iterating through the whole blasted file*/
if(opt&NOISY) printf("\t%s\nAllocating offset table...",opt&TABS ? "yes":"no");
fseek(txt,in,SEEK_SET);
  y=0;
  do{fgets(buf,0x10000,txt);
     if(opt&USERNUM)
       {entry=strtol(buf,0,16);
        if(entry>y) y=entry;
        }
     else y++;
     }while(!feof(txt));

/*write blank entries to output*/
if(opt&NOISY) printf("\twritting %i entries",y);
entry=0;
for(y*=4;pos<=y;pos+=4) fwrite(&entry,4,1,bin);
if(opt&NOISY) printf("\tDone!\nBeginning transcription... (be patient)");


/*Read for start of string when entry numbers are present
  if present, must always be followed by tabs
  entries end with newline*/
do{/*get position for new data in the text binary*/
  opt&=T_OFF;
  fseek(bin,0,SEEK_END);
  pos=ftell(bin);
  /*get one line of text*/
  fseek(txt,in,SEEK_SET);
  fgets(buf,0x10000,txt);
  in=ftell(txt);
  /*if you're reading entry numbers, do so.  otherwise, write running tally*/
  if(opt&USERNUM) {entry=strtol(buf,0,16); entry*=4;}
  fseek(bin,entry,SEEK_SET);
  y=byteswap(pos);
  fwrite(&y,4,1,bin);
  entry+=4;

/*if line numbers are present, advance past them*/
  strpos=0;
  if(opt&LINE) strpos=strcspn(buf,"\t\n\r")+1;

/*feed in text from string and output the line*/
  for(fseek(bin,pos,SEEK_SET);strpos<strlen(buf);strpos++)
     {x=buf[strpos];
      if(x<0x20)
        {fputc(0,bin);
         break;
         }
      else if(x<0x80)
        {if(x=='\\')
           {strpos++;
            x=tolower(buf[strpos]);
            if(x=='n') putc(0xA,bin);
            else if(x=='\\') putc('\\',bin);
            else if(x=='s') opt&=T_OFF;
            else if(x=='l')
                 {opt&=T_OFF;
                  opt|=LARGE;
                  }
            else if(x=='f')
                 {opt&=T_OFF;
                  opt|=FIXED;
                  }
            else if(x=='h')
                 {strpos++;
                  strncpy(sample,buf+strpos,4);
                  y=strtol(sample,0,16);
                  z=shortswap(y&0xFFFF);
                  fwrite(&z,2,1,bin);
                  strpos+=3;
                  }
            else erratta(1,1);
            }/*end \ detection*/
         else putc(x,bin);
         }/*end ASCII*/
      else
         {/*send out for japanese lookup*/
          strncpy(sample,buf+strpos,3);
          if(opt&LARGE) y=UTF8(sample,Ltbl,Lsource,Lnum,bin,opt);
          else          y=UTF8(sample,Stbl,Ssource,Snum,bin,opt);
          strpos+=y;
          continue;
          }/*end japanese*/
      }

}while(!feof(txt));      /*quit at eof*/

if(opt&NOISY) printf("\tDone!\n");
fclose(bin);
fclose(txt);
fclose(Lsource);
fclose(Ltbl);
fclose(Ssource);
fclose(Stbl);

return 0;}
