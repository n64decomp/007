#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/*special debugging flag*/
#define DEBUGGERY 0
/*if you aren't targtting an Intel system, set to 0!*/
#define SWAPO     1
/*these are flag values for the mode type*/
#define NORM      0x0
#define LARGE     0x1
#define FIXED     0x2
#define HEX       0x4

/*this global variable is used to keep from displaying error messages repeatedly*/
struct bit_field{
       int NoErrors   :1;
       int over80cap  :1;
       int overC0cap  :1;
       int TextOut    :1;
       int LineNum    :1;
       int StrLength  :1;    /*removed temporarily*/
       int Quiet      :1;
       int Joutput    :1;
       }errflag;

/*standard 32bit byteswapping*/
unsigned long byteswap(unsigned long w)
{if(SWAPO) return (w >> 24) | ((w >> 8) & 0x0000ff00) | ((w << 8) & 0x00ff0000) | (w << 24);
 return w;
}    

/*standard 16bit byteswapping*/
/*unsigned short int shortswap(unsigned short int w)
{if(SWAPO) return (w >> 8) | (w << 8);
 return w;
}*/

/*make happy japanese output using best-guess values
  note I have no conversion table for the kanji, so bugger them for now*/
int Jcopy(unsigned short code,FILE *tbl,unsigned long num,FILE *source,FILE *out)
{unsigned long pos,x;
 unsigned char buffer[20];
 
 /*translate a code value into an offset
   C000      type: 2=normal japanese, 3=large japanese
   3F00      bank#
   0080      identifies as nonASCII character
   007F      entry in bank
   
   actual offset is returned using this format:
   1F80      bank#
   007F      entry in bank
   */
 if(DEBUGGERY) printf("code: %04X\t",code);
 pos=code&0x7F;
 code=code&0x3F00;
 code=code>>1;
 pos|=code;
 if(DEBUGGERY) printf("index: %X\ttotal: %X\toutput %s\n",pos,num,pos>num ? "failed":"OK!");
 if(pos>num) return 0;    /*return bad if beyond indexed value*/
 pos=pos<<2;              /*pos->offset in table*/
  
 /*get string from source using table*/
 fseek(tbl,pos,SEEK_SET);
 fread(&pos,4,1,tbl);
 fseek(source,pos,SEEK_SET);
 fgets(buffer,20,source);
 
 /*trim off trailing newlines*/
 if(DEBUGGERY) printf("\tstring @ 0x%X, %i bytes:\t",pos,strlen(buffer));
 for(pos=strlen(buffer);pos>0;pos--)
    {x=buffer[pos];
     if(x<0x20) buffer[pos]=0;
     else break;
     }
 
 /*write to output file and return #characters written*/
 if(DEBUGGERY) {for(pos=0;pos<strlen(buffer);pos++) printf("%02X",buffer[pos]);
               printf("\n\t%i bytes written\n",strlen(buffer));
               }
 pos=fputs(buffer,out); 
 return pos;}

/*this indexes the entries in the text language source files
  returns number of entries, and more importantly puts them in a file provided
  text has to be in text mode, list in binary*/
long jubilee(FILE *text, FILE *list)
{unsigned long x=3,y=0;
 char buffer[20];
 
 fseek(list,0,SEEK_SET);
 do{fseek(text,x,SEEK_SET);
    fgets(buffer,20,text);
    fwrite(&x,4,1,list);
    if(!buffer) break;
    y++;
    x=ftell(text);
    }while(!feof(text));
 
 return y;}

/*Here goes! command line options:
all options can be upper or lower case, preceeded by - or /
L   no line numbers; must also cite again to recompile
T   no text ouptut, if you just want to see command values or something
C   no command output, to just view text
B   force binary output for both 7F/80 commands; undoes -7 and -8
7   7FXX commands use aliases, not explicit binary
8   80XX commands use aliases, not explicit binary
Q   quiet mode
H   help; this list, in other words
*/

int main(int argc, char *argv[])
{char filename[130],buf[4];
FILE *Ltbl,*Stbl,*Ssource,*Lsource,*txt,*out;

unsigned long pos,final,cur,len,Snum,Lnum;
unsigned char x,flag=0;
unsigned short y;

/*initialize all the error doohickies*/
errflag.over80cap=0;
errflag.overC0cap=0;
errflag.NoErrors=1;
/*optional options*/
errflag.Quiet=0;
errflag.LineNum=1;
errflag.StrLength=0;
errflag.Joutput=1;

/*parse command line*/
len=0; pos=0;
for(x=1;x<argc;x++)
    {if(argv[x][0]=='-' || argv[x][0]=='/')
      {switch(argv[x][1])
             {case 'Q': case 'q': errflag.Quiet=1;     break;
              case 'N': case 'n': errflag.LineNum=0;   break;
              case 'S': case 's': errflag.StrLength=1; break;
              case 'F': case 'f': errflag.Joutput=1;   break;
              case 'L': case 'l': pos=x; break;
              case 'H': case 'h': case '?':
                  printf("\nConverts GoldenEye text binary to UTF-8 text file");
                  printf("\n  /Q or -Q\t+\tquiet mode");
                  printf("\n  /N or -N\t+\tremove line numbers");
                  printf("\n  /F or -F\t+\tdisable output of 8/Cxxx characters");
                  printf("\n  /L or -lname\t+\tallows you to name the language files to be used");
                  /*printf("\n  /8 or -8\t+\tto be implemented");*/
                  printf("\n  /H, /?, -H, or -?\tdisplay this help message");
                  printf("\n\n\tPress -enter- to quit"); getchar(); return 0;
              }    
      }
    else len=x;
    }

/*find the table files*/
chdir(dirname(argv[0]));   /*theoretically returns program's directory*/
/*create table for 8xxx text entries*/
if(pos) strcpy(filename,argv[pos]+2);
   else strcpy(filename,"japanese.txt");
if(DEBUGGERY) Stbl=fopen("smallJtable.bin", "wb+");
   else Stbl=tmpfile();
if(!Stbl)
  {fprintf(stderr,"Unable to make a temporary index for \"%s\"\r",filename);
   getchar();
   return 1;
   }
while (!(Ssource = fopen(filename, "rt"))) {
	printf("\nWhat's the path to the file \"japanese.txt\"? ");
	strcpy(filename,"\0");	
	gets(filename);
    }
Snum=jubilee(Ssource,Stbl);

/*create table for Cxxx text entries*/
if(strrchr(filename,'.')) strcpy(strrchr(filename,'.'), "large.txt");
   else strcat(filename,"large");
if(DEBUGGERY) Ltbl=fopen("largeJtable.bin", "wb+");
   else Ltbl=tmpfile();
if(!Ltbl)
  {fprintf(stderr,"Unable to make a temporary index for \"%s\"\r",filename);
   getchar();
   return 2;
   }
while (!(Lsource = fopen(filename, "rt"))) {
	printf("\nWhat's the path to the file \"japaneselarge.txt\"? ");
	strcpy(filename,"\0");	
	gets(filename);
    }
Lnum=jubilee(Lsource,Ltbl);

/*open input files*/
if(len) strcpy(filename,argv[len]);
else strcpy(filename,"\0");
while (!(txt = fopen(filename, "rb"))) {
	printf("\ntext binary file? ");
	strcpy(filename,"\0");	
	gets(filename);
    }

    if(strrchr(filename,'.')) strcpy(strrchr(filename,'.'), ".txt");
    else strcat(filename, ".txt");
while (!(out = fopen(filename, "wt"))) {
	printf("\noutput filename (.txt)? ");
	strcpy(filename,"\0");	
	gets(filename);
    }

/*guess the number of entries.
  We have to assume entry one is the start of the text bank*/
fseek(txt,0,SEEK_SET);
fread(&final,4,1,txt);
final=byteswap(final);

/*now to parsing text*/
cur=0;             /*start entry (0) doesn't exist...*/
buf[0]=0xEF; buf[1]=0xBB; buf[2]=0xBF; buf[3]=0;
fprintf(out,"%s",buf);         /*set the header for the output*/

for(pos=0;pos!=final;pos+=4)   /*pos+final keep track in table*/
   {/*advance through index and get next offset*/
    fseek(txt,pos,SEEK_SET);
    fread(&cur,4,1,txt);
    cur=byteswap(cur);

/*I think this bit was for the line numbers on the side*/
if(errflag.LineNum) fprintf(out,"%04X\t",pos/4);

/*handle strings*/
   len=0;
   do{fseek(txt,cur,SEEK_SET); x=getc(txt);

        if(!x) break;
        /*handle the special mode IDs here*/
        if(flag&LARGE)
          {if(x!=0xC0)
             {fprintf(out,"\\s");
              flag=NORM;
              }
           }
        if(flag&FIXED)
          {if(x<0x80)
             {fprintf(out,"\\s");
              flag=NORM;
              }
           }
        if(flag&HEX)
          {fprintf(out,"\\s");
           flag=NORM;
           }
        
        if(!x) break;
        
        if(x&0x80)
          {cur+=2;
           if(errflag.Joutput)
             {y=x<<8;
              x=getc(txt);
              y|=x;
              /*determine specific type*/
                if(y&0x4000){/*C0 commands use a thingy to indicate their case*/
                   if(!(flag&LARGE))
                     {fprintf(out,"\\l");
                      flag=NORM;
                      flag|=LARGE;
                      }
                   if(!Jcopy(y,Ltbl,Lnum,Lsource,out)) errflag.overC0cap=1;
                   else len++;
                   }
                else {/*80 commands can use fixed-width ascii characters*/
                     if(Jcopy(y,Stbl,Snum,Ssource,out)) errflag.over80cap=1;
                     else len++;
                     }
             }/*errflag.Joutput*/
           }/*end Japanese support*/
        else {if(x==0xA) fprintf(out,"\\n");
              else fprintf(out,"%c",x);
              len++;
              cur++;}
        
        }while(1);
   /*terminate your string, then print sizes and inline-error messages*/
   fprintf(out,"\n");
   if(errflag.StrLength) fprintf(out,"strlen\t0x%X\n",len);
   if(!errflag.Quiet){
    if(errflag.over80cap) {fprintf(stderr,"%X \tUnknown 8xxx character!\n",pos/4);errflag.NoErrors=0;errflag.over80cap=0;}
    if(errflag.overC0cap) {fprintf(stderr,"%X \tUnknown Cxxx character!\n",pos/4);errflag.NoErrors=0;errflag.overC0cap=0;}
    }
   }/*end for()*/

fclose(Stbl);
fclose(Ssource);
fclose(Ltbl);
fclose(Lsource);
fclose(txt);
fclose(out);

if(!errflag.Quiet){
 printf("\n\nShaznastic!  Your output is in %s",filename);
 if(!errflag.NoErrors) printf("\nA couple errors occured in there.\nTry revising the script to avoid them.");
}
return 0;}
