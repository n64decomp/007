#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*global variables*/
FILE *pins;
FILE *maps;
FILE *pout;
FILE *pbin;
int rerun=0, convert=0, game=16, imagedim[2];
unsigned long table[3][4], group=0, offset=0;
union funky{unsigned char cop[8]; long lop[2];} opcode;

long opswap();
/*dxf declarations*/
int dxfheader();
int dxf_E7();
int dxf_04();
int dxf_C0();
int dxfoutput();
int dxfeof();
int dxfrepeat();
/*obj declarations*/
int objheader();
int obj_E7();
int obj_04();
int obj_C0();
int objoutput();
int objeof();
int objrepeat();

/*main loop*/
int main(int argc, char *argv[])
{char filename[130];
int i=0,j=0;
unsigned char y;
unsigned long x=0,sout=0;

/*function pointer declaration*/
struct nifty{int (*header)();int (*E7)();int (*o4)();int (*C0)();int (*output)();int (*eof)();int (*repeat)();} p3d[2];
p3d[0].header = dxfheader;
p3d[0].E7 = dxf_E7;
p3d[0].o4 = dxf_04;
p3d[0].C0 = dxf_C0;
p3d[0].output = dxfoutput;
p3d[0].eof = dxfeof;
p3d[0].repeat = dxfrepeat;
p3d[1].header = objheader;
p3d[1].E7 = obj_E7;
p3d[1].o4 = obj_04;
p3d[1].C0 = obj_C0;
p3d[1].output = objoutput;
p3d[1].eof = objeof;
p3d[1].repeat = objrepeat;

Selecto:
for(;;)
    {system("CLS");
    printf("GE/PD Room -> 3D.ext Converter\n\nWhich game will you be hacking today?\n----------\n1\tGoldeneye\n2\tPerfect Dark\n----------\nPress Spacebar to quit");
    switch(getch())
        {default: continue; break;
        case ' ': return 0; break;
        case '2': game = 12; break;
        case '1': game = 16; break;
        } break;
    }        

for(;;)
    {system("CLS");
    printf("%s Room -> 3D.ext Converter\n\nSelect a conversion type:\n----------\n1\tAutoCAD .dxf format (no textures)\n2\tWavefront .obj format (no RGBA support)\n----------\nPress Spacebar to quit\nPress Backspace to select a different game",game>12 ? "Goldeneye":"Perfect Dark");
    switch(getch())
        {default: continue; break;
        case ' ': return 0; break;
        case '\b': goto Selecto; break;
        case '2': convert = 1; break;
        case '1': convert = 0; break;
        } break;        
    }    
/*load up those three files. remember, you're writting text, reading binary*/
while((pins = fopen(filename,"rb"))==NULL)
        {printf("\nuse only non-byteswapped files!\n\nPoint file to open: ");
        gets(filename);}
        strcpy(filename, "\0");
while((maps = fopen(filename,"rb"))==NULL)
        {printf("\nMapping for room: ");
        gets(filename);}
        strcpy(filename, "\0");
while((pout = fopen(filename,"w"))==NULL)
        {printf("\n(note: be sure to add the extension to your output file!)\nName of output file: ");
        gets(filename);}
/*set up output file and other initial code*/
p3d[convert].header();

/*loop for second mapping file.  yes, it's a goto...*/
again:
/*determine file size, so this stupid thing doesn't keep running on*/
fseek(maps,0,SEEK_END);
sout=ftell(maps);
rewind(maps);

group=0;
/*read the mapping...
read in commands 8 bytes at a time.  check first byte to determine command
(add others later if applicable*/
for(x=0;(8*x)< sout;fseek(maps,8*x++,SEEK_SET)) 
    {fread(opcode.cop,1,8,maps);
    switch(opcode.cop[0])
        {
        /*E7 group code.  just sets each group to a new layer*/
        case 0xE7:
                p3d[convert].E7(); continue;
        /*04 point table offset type
        not fully implemented.
        Eventually allow different offsets*/
        case 0x04:
                p3d[convert].o4(); continue;
        /*C0 image group.  refer to values in sub's images...
          Needs to be in GErom image editor main directory*/
        /*F0 is used after stage decompression, but no way to link without running facemapper
        C0 needs to be known BEFORE mapping vt in wavefront.  
        only C0 is supported at this time*/
        case 0xC0:
                p3d[convert].C0(); continue;
        /*B1 triangle draw type*/
        case 0xB1:
                /*function to read points.  [vertex1,vertex2,vertex3][4,3,2,1]*/
                /*z points*/
                for(i=0;i<4;i++)
                                {
                                y = opcode.cop[2+i/2];
                                if((i%2)==0) y=y>>4;
                                y = y&0x0F;
                                table[2][i]=(long)y;
                                }
                /*y+x points*/
                for(i=0;i<4;i++)
                                {for(j=0;j<2;j++)
                                                {y = opcode.cop[4+i];
                                                if((j%2)>0) y=y>>4;
                                                y = y&0x0F;
                                                table[j][i]=(long)y;
                                                }    
                                }
                                /*output triangle stuff...*/
                p3d[convert].output();
                continue; 
        /*BF single triangle draw type*/
        case 0xBF:
            /*set all points in table[][] to zero, then use standard p3d[convert].output
            read z,y,x into slot 4*/
            memset(table,0,48);
            opcode.lop[0] = 0;
            for(i=0;i<3;i++)
                {opcode.cop[0]= opcode.cop[5+i];
                table[i][3] = opcode.lop[0] / 10;
                } 
               p3d[convert].output();
               continue;   
        case 0xB8:/*unti clump, used prior to mapping data in most N64 games*/
            break;
        }/*this ends switch*/           
    }/*end of for loop (mapping data)*/
fclose(maps);
if(rerun<1)
    {rerun++;
    printf("Do you want to load a second mapping file for this room?\n[Y]es, or [N]\n");
switch(getch())
        {case 'Y': case 'y': 
        strcpy(filename, "\0");
        while((maps = fopen(filename,"r"))==NULL)
                {printf("\nName of other mapping file: ");
                gets(filename);}
        strcpy(filename, "\0");
/*function to run if repeating*/
        p3d[convert].repeat();
            goto again;
        default: break;
        }        
    }
/*EOF for dxf*/
p3d[convert].eof();    

fclose(pins); fclose(pout);
printf("all done.  Just press any key to quit.");
  getch();	
  return 0;
}

/**************************************************************************
*generic helper functions*
**************************************************************************/

long opswap()
    {int i=0;
    opcode.cop[4] = 0x0;
    for(i=0;i<4;i++) opcode.cop[i]=opcode.cop[7-i];
    return opcode.lop[0];}

/**************************************************************************
*dxf conversion files.  probably export to their own includes or something*
**************************************************************************/
int dxfheader()
{fprintf(pout,"999\nGE Reclipping Project\n999\nGoldeneye Model Data Export Project\n0\nSECTION\n2\nENTITIES\n");
return 1;}

int dxf_E7()
    {group++;
    return 1;}

int dxf_04()
    {offset = opswap();
    return 1;}

int dxf_C0()
    {return 1;}

int dxfoutput()
    {int i=0,j=0;    
    union aegh{short int spin[3]; unsigned char cpin[6];} points,assist;
    
    
    for(i=0;i<4;i++)
        {if(table[0][3-i]==table[1][3-i]) break;
        fprintf(pout,"0\n3DFACE\n8\n%s %i\n62\n3\n",rerun==0 ? "room":"frills",group);
        for(j=0;j<4;j++)
                {fseek(pins,offset+(game * table[j-(j==3)][3-i]),SEEK_SET);
                fread(assist.spin,2,3,pins);
                points.cpin[0]=assist.cpin[1];
                points.cpin[2]=assist.cpin[3];
                points.cpin[4]=assist.cpin[5];
                points.cpin[1]=assist.cpin[0];
                points.cpin[3]=assist.cpin[2];
                points.cpin[5]=assist.cpin[4];
                fprintf(pout,"%i\n%i\n%i\n%i\n%i\n%i\n",10+j,points.spin[0],20+j,points.spin[1],30+j,points.spin[2]);
                } 
        }
return 1;
}

int dxfeof()
{fprintf(pout,"0\nENDSEC\n0\nEOF\n");
return 1;}

int dxfrepeat(){}

/**************************************************************************
*Wavefront .obj conversion files.  probably export to their own includes*
**************************************************************************/
int objheader()
    {unsigned long psize=0, i=0;
    int j=0;
    union help{unsigned char ch[16];short int si[8];} assist;
        
    fprintf(pout,"# GE Reclipping Project\n# Goldeneye Model Data Export Project\ng Primary Mapping\n");
    /*read tableBinary.bin to get image address numbers.  Granted, not actually output as them, but screw it*/
    if((pbin = fopen("tableBinary.bin","rb"))==NULL)
        {printf("Since RareWitch's tableBinary.bin is not in this directory,\nimage mapping will be commented out and image index numbers given.\n");
        fclose(pbin);}    
    /*read in entire point table.  first vertices, then image mapping.  RGBA not available*/
    /*determine max loop size*/
    fseek(pins,0,SEEK_END);
    psize = ftell(pins);
    rewind(pins);
    /*vertices and image vu coords (or whatever you'd like to call them*/
    for(i=0;i<psize;i+=game)
        {fseek(pins,i,SEEK_SET);
        for(j=1;j<17;j++)
                assist.ch[j-(2 * ((j%2)==0))]=fgetc(pins);
/*        fprintf(pout,"v %i %i %i\nvt %i %i\n",assist.si[0],assist.si[1],assist.si[2],assist.si[4] / 0x20,assist.si[5] / 0x20);
neither will work.  Take image size and divide by original dimentions... those are percentages, used by this*/
        fprintf(pout,"v %i %i %i\nvt %i %i\n",assist.si[0],assist.si[1],assist.si[2],assist.si[4]!=0 ? 1:0,assist.si[5]!=0 ? 1:0);
        }    
    return 1;}
    
int obj_E7()
    {fprintf(pout,"o %s_%i\n",rerun==0 ? "Room":"Frills",group++);
    return 1;}

int obj_04()
    {offset = opswap() / 0x10;
    offset++;
    return 1;}

int obj_C0()
    {long i;
    i=opswap();
    fprintf(pout,"# image index number %lX\n",i);
    if((pbin = fopen("tableBinary.bin","rb"))!=NULL) 
        {fseek(pbin,i*4,SEEK_SET);
        fread(&i,4,1,pbin);
        fprintf(pout,"# usemat %lX.bmp\n",i);
        fclose(pbin);
        }
    return 1;}

int objoutput()
    {int i=0;
    for(i=0;i<4;i++)
        {if(table[0][3-i]==table[1][3-i]) break;
        fprintf(pout,"f %u/%u %u/%u %u/%u\n",table[0][3-i]+offset,table[0][3-i]+offset,table[1][3-i]+offset,table[1][3-i]+offset,table[2][3-i]+offset,table[2][3-i]+offset);
        }
    return 1;}
            
int objeof()
    {if(pbin!=NULL) fclose(pbin); 
    return 1;}

int objrepeat()
    {fprintf(pout,"g Secondary_Mapping\n");
    return 1;}
