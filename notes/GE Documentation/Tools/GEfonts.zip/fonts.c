#include <stdio.h>
#include <stdlib.h>

int region(FILE *in);
int C0extracter(FILE *in, FILE *out, unsigned short i, unsigned short n, int r);
int AZstract(FILE *in, FILE *out, char c, int res, int r);
unsigned short mnemonics(unsigned short c);
unsigned char Jsample(unsigned char i, int n);
unsigned long byteswap(unsigned long w);

/*sets tags for the four possible font extraction modes*/
enum{ASCII_FONT,
     ALL_J,
     JS_80,
     JS_C0};

/*N64 country IDs, to save the trouble of remembering them*/
enum{JU=0x41,    /*NTSC - no region (JU)*/
	 GER=0x44,   /*PAL - German*/
     USA,	     /*NTSC - North American release (english)*/
	 FR,	     /*PAL - French*/
	 IT=0x49,	 /*PAL - Italian*/     
	 JAP,	     /*NTSC - Japan*/
	 PAL=0x50,	 /*PAL - England or generic European release*/
	 SP=0x53,	 /*PAL - Spanish*/
	 AUS=0x55,	 /*PAL - Australia*/
	 GER_MULTI=0x58,	/*PAL - German (multi)*/
	 ENG_MULTI	 /*PAL - English (multi)*/
     };

/*main file handing loops*/
int main(int argc, char *argv[])
{FILE *in, *out;
char filename[130];
int reg;
unsigned char x;

    if(argc>1) strcpy(filename,argv[argc-1]);
while (!(in = fopen(filename, "rb"))) {
	printf("\nROM filename? ");
	strcpy(filename,"\0");	
	gets(filename);
    }

reg=region(in);
if((reg!=USA) && (reg!=JAP) && (reg!=PAL))
  {printf("You have a different version game than expected.");
  printf("\nOnly USA, Japanese, and PAL (eng.) accepted\n");
  system("PAUSE");
  exit(1);
  }

/*
    strtok(filename,".");
    strcat(filename, ".tga");
while (!(out = fopen(filename, "wb"))) {
	printf("\noutput file? ");
	strcpy(filename,"\0");	
	gets(filename);
    }
*/

/*this loop extracts all small ASCII samples
  I'm pretty sure that's watch text*/
for(x=0x21;x<0x7E;x++)
   {sprintf(filename,"small-%X.tga",x);
   while (!(out = fopen(filename, "wb"))) {
	 printf("\noutput file for '%c'? ",x);
	 strcpy(filename,"\0");	
	 gets(filename);
     }
   AZstract(in,out,x,0,reg);
   fclose(out);
   }
/*this loop extracts all large ASCII samples
  yes, I know they could have been combined...*/
for(x=0x21;x<0x7E;x++)
   {sprintf(filename,"large-%X.tga",x);
   while (!(out = fopen(filename, "wb"))) {
	 printf("\noutput file for '%c'? ",x);
	 strcpy(filename,"\0");	
	 gets(filename);
     }
   AZstract(in,out,x,1,reg);
   fclose(out);
   }

	 strcpy(filename,"JS.tga");	
   while (!(out = fopen(filename, "wb"))) {
	 printf("\noutput file for '%c'? ",x);
	 strcpy(filename,"\0");	
	 gets(filename);
     }
Jstract(in,out,reg); /*extracts all JS types into one file!*/
fclose(out);

fclose(in);
  
  return 0;
}

/*grabs region code*/
int region(FILE *in)
{fseek(in,0x3E,SEEK_SET);
return fgetc(in);
}

/*retrieves a single ASCII [c]haracter from either lo or hi [res] and writes to file
  Use the actual ASCII representation of the character as index.*/
int AZstract(FILE *in, FILE *out, char c, int res, int r)
{unsigned long x,addy;
int wide,woff;
int hi,y,count;
unsigned char head[18]={0,0,3,0,0,0,0,0,0,0,0,0,0,0,0,0,8,32};

/*whitespace and above 0x7D not valid*/
if((c<0x21) | (c>0x7D)) return 0;
c-=0x21;

if(r==JAP) {if(res<1) addy=0x2E7108; else addy=0x2E95B8;}
else if(r==USA) {if(res<1) addy=0x2E63E8; else addy=0x2E8898;}
else if(r==PAL) {if(res<1) addy=0x2DC828; else addy=0x2DECD8;}
x= addy+(c*24)+0x2AC;

fseek(in,x+11,SEEK_SET);
hi=fgetc(in);
fseek(in,x+15,SEEK_SET);
wide=fgetc(in);
woff=(wide%8)>0;
woff=woff+(wide/8);
woff*=8;
fseek(in,x+20,SEEK_SET);
fread(&x,4,1,in);
x=byteswap(x)+addy+8;

/*write te header*/
head[12]=wide;
head[14]=hi;
fwrite(head,1,18,out);

#ifdef _DEBUG_
printf("\nDebugorama!\nc: %c\taddy: %X\tw: %i\th: %i",c+0x21,x,wide,hi);
#endif

/*grab the image*/
for(count=0;hi>0;hi--)
   {fseek(in,x,SEEK_SET);
   for(y=0;y<wide;y++) fputc(fgetc(in),out);
   x+=woff;
   count+=woff;
   }

/*tack on the tail*/
x=0;
fwrite(&x,4,1,out);
fwrite(&x,4,1,out);
strcpy(head,"TRUEVISION-XFILE.");
fwrite(head,1,18,out);

return count;}

/*just makes a really huge mess of images!*/
int Jstract(FILE *in, FILE *out, int r)
{unsigned long x;
long y,z;
unsigned char buf[32]={0,1,1,0,0,16,0,24,0,0,0,0,32,0,48,26,8,32,0,0,0,85,85,85,170,170,170,255,255,255};

/*establish targa header*/
fwrite(buf,1,30,out);
fwrite(buf+18,1,12,out);
fwrite(buf+18,1,12,out);
fwrite(buf+18,1,12,out);

if(r==JAP) x=0x118660;
else if(r==USA) x=0x117940;
else if(r==PAL) x=0x1048B0;
for(y=0;y<0xD180;y+=8)
   {fseek(in,x+y,SEEK_SET);
   for(z=0;z<16;z+=2)
      {buf[z]=fgetc(in);
      buf[z+1]=buf[z]&0x3;
      buf[z+17]=(buf[z]&0xC)>>2;
      buf[z+16]=(buf[z]&0xC0)>>6;
      buf[z]=buf[z]>>4;
      }
   fwrite(buf,1,32,out);
   }
z=0;
fwrite(&z,4,1,out);
fwrite(&z,4,1,out);
strcpy(buf,"TRUEVISION-XFILE.");
fwrite(buf,1,18,out);

return 0;}


/*extracts images from [i]nitial to e[n]dpoint
  [r]egion codes are required to extract data
  images are placed in *out; returns final ID extracted or -1 if error*/
int C0extracter(FILE *in, FILE *out, unsigned short i, unsigned short n, int r)
{unsigned long x;
int y;
unsigned char c;
    
/*ensure some idiot didn't send the actual code value instead of internal*/
if(i&0x4000) {i=mnemonics(i); if(i==0xFFFF) return -1;}
if(n&0x4000) {n=mnemonics(n); if(n==0xFFFF) return -1;}

/*check that i and n are both C0xx types and below C0DA*/
if((i&0x2000) & (n&0x2000))
  {if(i>=0x205A) return -1;
  if(n>=0x205A) n=0x205A;
  }
else return -1;

/*now that you're sure, strip the ID codes!*/
i&=0x1FFF;
for(n&=0x1FFF;i<n;i++)
   {x=(i>>1)*0x80;
   if(r==JAP) x+=0x123D60;
   else if(r==USA) x+=0x123040;
   else if(r==PAL) x+=0x10FFB0;
   fseek(in,x+y,SEEK_SET);
   for(y=0;y<0x80;y++)
      {c=fgetc(in);
      c=Jsample(c,i);
      fputc(c,out);
      }
   }
return i;
}

/*converts wide char [c]ode values into internal numbering system
  accepts 8080-87D0 and C080-C0EA; returns code or -1 if error*/
unsigned short mnemonics(unsigned short c)
{unsigned short x=-1;
/*test if valid*/
if(c&0x8000)
  {if(c&0x80)
    {x=c&0x7F00;
    c&=0x7F;
    x=(x>>2)+c;
     }
   }
return x;}

/*uses the sample [n]umber to convert char [i]n
  into the sample used for the given image*/
unsigned char Jsample(unsigned char i, int n)
{unsigned char x;
n=n&1;
x=0x33<<n;
return (i&x);}

unsigned long byteswap(unsigned long w)
{return (w >> 24) | ((w >> 8) & 0x0000ff00) | ((w << 8) & 0x00ff0000) | (w << 24);
}    
