  To use, either drag-and-drop your rom onto the program or type in the full path to it when it asks for a rom.  It must be *unbyteswapped*, but can be any region game.  This is a console program so if the filename is too long it won't be able to open it; it works best if your rom is somewhere near the drive letter or in the same folder.

  The program outputs all of the variable-sized ASCII as individual files and all the japanese fonts in  a single file named JS.  The images are targas, which concidering how old a format they are there's bound to be something that can open them.  They're a native format on my win16 machine, at any rate.

  Also included is a png conversion of the japanese font table that someone else requested.  In that case, the images were flattened to transparency instead of the native black.  This is more the way you'd see it in the RCP's tmem.  

  The JS output is very specificly formatted.  On the left is the first image, and on the right is the one embedded at the same memory location.  So, counting down from the top, you get 8080+8081, 8082+8083, 8084+8086, etc.  The initial kana/hana/roma are sorted by one of the standard codepages (can't remember off the top of my head) but the kanji aren't, so to translate them would suck royally.  You'd basically have to build a codepage to do it, and quite honestly I'm just not sure how.  Otherwise, you *could* use microsoft's little font extension program to push each character to a higher but equivalent value (C080, etc.) but to do that you'd have to draw each one.  Aegh!

-Zoinkity
