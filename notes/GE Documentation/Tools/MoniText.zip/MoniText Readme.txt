MoniText v0.1
+-+-+-+-+-+-+

  When fed a monitor binary, this program will decompose it into readable english.  A companion program is in development to recompile this script back into a binary.
  Note that this is written specificly to use the revised monitor format, so each command is expected to be two bytes, not four.
  As of this version, the original 0-F commands as well as the new 10-15 commands are implemented.

+_+
  
Usage:
  You can simply drag-and-drop the binary file onto MoniTear.exe to automatically generate a text file of the same name.  Otherwise, the program will prompt you for a filename.
  MoniText is best used from the command line.  All options can be preceeded with either '-' or '/', upper or lower case.

MoniTear.exe <filename.ext> [-O<filename.txt>] [-N] [-E<#>] [-L<filename.log>] [-H]
	-Ofilename.txt	output filename.
	-Lfilename.log	error log filename, in case you need one
	-N	file doesn't include a table of entries
	-E#	file contains given # entries, used when the first entry doesn't point at the beginning of the monitor microcode
	-H or -?	display this short help message

-_-

Reading the Output:
  Each binary command is output in a specific way and therefore is clearly identifable.  Each command is one statement, usually a sentance, and ends with a period.
  Note that since it is impossible to determine the images each command may use, hexadecimal values are used in place of percentages for all shift, stretch, and zoom commands.

Animation_##:
	An animation label, used to determine where each one starts.
Label_##:
	These labels are used by jump and branch command types to determine their targets.  If labels are not in use or a matching one can not be found, the actual offset is given in the text.

0000
	Stop Scrolling.
0001.xxxx.tttt
	Scroll horizontally [x] over [t] seconds.
0002.yyyy.tttt
	Scroll vertically [y] over [t] seconds.
0003.xxxx.tttt
	Shift horizontally [x] over [t] seconds.
0004.yyyy.tttt
	Shift vertically [y] over [t] seconds.
0005.xxxx.tttt
	Stretch horizontally [x] over [t] seconds.
0006.yyyy.tttt
	Stretch vertically [y] over [t] seconds.
0007.iiii
	Use image [i].
0008.tttt
	Wait for [t] seconds.
0009.aa.oo
	Jump to [Label].
	Jump to Animation_[a].
	Jump to Animation_[a], offset [o].
000A.aa.oo.ffff
	Jump to [Label] with [f]% frequency.
	Jump to Animation_[a] with [f]% frequency.
	Jump to Animation_[a], offset [o] with [f]% frequency.
000B
	Loop.
000C
	Stop Animation.
000D.RRGGBBAA.tttt
	Change color to [RRGGBBAA] over [t] seconds.
000E.rrrrrrrr
	Position at [r] degrees.
000F.rrrrrrrr
	Rotate [r] degrees.
0010.oooo.ffff
	Branch to [Label] with [f]% frequency.
	Branch [+-o] commands with [f]% frequency.
0011.aa.oo
	Jump and link to [Label].
	Jump and link to Animation_[a].
	Jump and link to Animation_[a], offset [o].
0012.oooo
	Branch and link to [Label].
	Branch and link [+-o] commands.
0013.oooo
	Branch to [Label].
	Branch [+-o] commands.
0014.tttt.oooo
	Branch to [Label] [t] times.
	Branch [+-o] commands [t] times.
0015.zzzz.tttt
	Zoom [z] over [t] seconds.

*_*

Command Restrictions:
  There are a certain number of restrictions to keep in mind, some command-specific.

Infinite loops
  Monitor microcode needs breaks or it will run continually without jumping back to play.  08 wait, 14 loop, and 0C stop commands break execution.  You must insert these into your code at points, usually after setting movement commands.

Jump and Branch commands
  There are multiple formats for these commands, depending on whether labels are in use or not.
  The simplest usage is to set a label and simply tell it to branch to that label.  Otherwise, the offset is in halfwords, counting the binary values from the beginning of the next command.
  Branches can offset either forward or backward.  Jumps can only offset forwards from the start of an animation.

Labels
  Labels, at this point, must be numerical and named label.  Sorry for any inconvenience.

0007.iiii	Use image [i].
  This uses the global image bank, and the image number is an index from the start of the monitor image segment.  In an unhacked image bank, that restricts the values for i: -55 to 140.
  
0014.tttt.oooo	Branch to [Label] [t] times.
  The name is misleading.  The command uses the 'wait' command as its base and offsets either backward or forward a certain number of commands.  That means you can not use a wait or stop command within the looped code without the wait command draining the timer.

000B	Loop
  This returns the current animation to the point it started in the code.  You can move the start point using either the 'jump and link' or 'branch and link' commands.
  Here is an example:
"Animation_00: Use image 7.  Jump and Link to Label_00.
 Animation_01: Use image 8.  Jump and Link to Label_00.
 Label_00:
 Scroll 200% over 10 seconds.  Wait 10 seconds.
 Loop."
 Both animations set a different image, then JAL to Label_00.  The new start position is set now to Label_00, so when the loop command is reached, it jumps back to Label_00, not the original animation start point.

0015.zzzz.tttt	Zoom [z] over [t] seconds.
  This is a combination of the 'stretch' commands.  Use it in place of a 'horizontal+vertical' command combo when the image is square.

=_=

  Bug reports are always welcome.  

-Zoinkity	(nefariousdogooder@yahoo.com)
