#include <stdio.h>
#include <stdlib.h>

int unmush(FILE *in, FILE *out);
unsigned long byteswap(unsigned long w);

int main(int argc, char *argv[])
{char filename[130];
FILE *in, *out;

    if(argc>1) strcpy(filename,argv[1]);
while (!(in = fopen(filename, "rb"))) {
	printf("\nfiddle with what file? ");
	strcpy(filename,"\0");	
	gets(filename);
    }

    strtok(filename,".");
    /*something to select extension name*/
    strcat(filename, ".htm");
    if(argc>2) strcpy(filename,argv[2]);
while (!(out = fopen(filename, "wt"))) {
	printf("\noutput text name? ");
	strcpy(filename,"\0");	
	gets(filename);
    }

/*delegate it out*/
unmush(in, out);

  printf("\n\nAll done.  Demo is broken down in %s.\n", filename);
  system("PAUSE");	
  return 0;
}

/****************************************/
/*does the actual work*/
/****************************************/
int unmush(FILE *in, FILE *out)
{unsigned long suck, size, count, end, x, y;
unsigned char com;
char key;
long checkHI,checkLO,varA1,varA2;/*long longs aren't defined on my architecture*/

/*set up output file*/
fprintf(out,"<HTML>\n<HEAD><LINK REL=\"stylesheet\" HREF=\"res/pretty.css\"></LINK></HEAD>\n<BODY>\n<H1>");

rewind(in);
/*grab stage number*/
fseek(in, 0x13, SEEK_SET);
switch(fgetc(in))
      {case 0x09:
            fprintf(out,"09 Bunker I"); break;
      case 0x14:
            fprintf(out,"14 Silo"); break;
      case 0x16:
            fprintf(out,"16 Statue Park"); break;
      case 0x17:
            fprintf(out,"17 Control"); break;
      case 0x18:
            fprintf(out,"18 Archives"); break;
      case 0x19:
            fprintf(out,"19 Train"); break;
      case 0x1A:
            fprintf(out,"1A Frigate"); break;
      case 0x1B:
            fprintf(out,"1B Bunker II"); break;
      case 0x1C:
            fprintf(out,"1C Aztec"); break;
      case 0x1D:
            fprintf(out,"1D Streets"); break;
      case 0x1E:
            fprintf(out,"1E Depot"); break;
      case 0x1F:
            fprintf(out,"1F Complex"); break;
      case 0x20:
            fprintf(out,"20 Egyptian"); break;
      case 0x21:
            fprintf(out,"21 Dam"); break;
      case 0x22:
            fprintf(out,"22 Facility"); break;
      case 0x23:
            fprintf(out,"23 Runway"); break;
      case 0x24:
            fprintf(out,"24 Surface I"); break;
      case 0x25:
            fprintf(out,"25 Jungle"); break;
      case 0x26:
            fprintf(out,"26 Temple"); break;
      case 0x27:
            fprintf(out,"27 Caverns"); break;
      case 0x28:
            fprintf(out,"28 Citadel"); break;
      case 0x29:
            fprintf(out,"29 Cradle"); break;
      case 0x2B:
            fprintf(out,"2B Surface II"); break;
      case 0x2D:
            fprintf(out,"2D Basement"); break;
      case 0x2E:
            fprintf(out,"2E Stack"); break;
      case 0x30:
            fprintf(out,"30 Library"); break;
      case 0x32:
            fprintf(out,"32 Caves"); break;
      case 0x36:
            fprintf(out,"36 Cuba"); break;
      default:
            fprintf(out,"Unknown Stage"); break;
      }

/*Set # (not set # after all.  First of two randomizers)
fseek(in, 0x17, SEEK_SET);
com=fgetc(in);
fseek(in, 0x3, SEEK_SET);
x=fgetc(in);
x+=1;
if(com>0) x = x + com -1;
fprintf(out,"\tset #%i",x);*/

/*check value - it's a 64bit value, the little bugger
I can't use long longs, but this whole mess should work instead*/
checkHI=0;
checkLO=0;
fseek(in, 0x0, SEEK_SET);
fread(&checkHI,4,1,in);
fread(&checkLO,4,1,in);
checkHI=byteswap(checkHI);
checkLO=byteswap(checkLO);

/*Size of file*/
fseek(in, 0x80, SEEK_SET);
fread(&end,4,1,in);
fprintf(out,"</H1>\n<P><B>Size:</B> <I>%X</I>\n<BR /><B>Difficulty:</B> <I>",byteswap(end));

/*Duration of demo*/
fseek(in, 0x7C, SEEK_SET);
fread(&size,4,1,in);
size=byteswap(size);
fprintf(out,"<B>Time:</B> <I>%i:%i seconds</I>\n<BR /><B>Difficulty:</B> <I>",size/60,size%60);

/*difficulty*/
fseek(in, 0x17, SEEK_SET);
key=fgetc(in);
if(key<1) fprintf(out,"Agent");
else if(key<2) fprintf(out,"Secret Agent");
else if(key<3) fprintf(out,"00 Agent");
else if(key<4) fprintf(out,"007");

/*Number of players*/
fseek(in, 0x8F, SEEK_SET);
key=fgetc(in);
fprintf(out,"</I>\n<BR /><B>Players:</B> <I>%i</I>\n<BR /><BR /><B>Screen:</B> <I>",key+1);
/*technically, if more than 2 players then should grab controller types from block*/

/*video display mode*/
fseek(in, 0x28, SEEK_SET);
key=fgetc(in)&0x08;
if(key>0) fprintf(out,"Cinema; ");
else{fseek(in, 0x29, SEEK_SET);
  key=fgetc(in);
  fprintf(out,"%s; ",key&0x40 ? "Wide":"Full");
  }
/*Now the single-player options*/
fseek(in, 0x29, SEEK_SET);
key=fgetc(in);
fprintf(out,"%s</I>\n<BR /><B>Ammo On-Screen:</B> <I>%s</I>\n<BR /><B>Look Ahead:</B> <I>%s</I>\n<BR /><B>Sight On-Screen:</B> <I>%s</I>\n<BR /><B>Aim Control:</B> <I>%s</I>\n<BR /><B>Auto Aim:</B> <I>%s</I>\n<BR /><B>Look Up/Down:</B> <I>%s</I>\n<BR />",key&0x80 ? "16:9":"Normal",key&0x20 ? "On":"Off",key&0x10 ? "On":"Off",key&0x08 ? "On":"Off",key&0x04 ? "Toggle":"Hold",key&0x02 ? "On":"Off",key&0x01 ? "Upright":"Reverse");

/*get size of commands from controller config*/
fseek(in, 0x18, SEEK_SET);
fread(&size,4,1,in);
size=byteswap(size);
fprintf(out,"<BR /><B>Controllers:</B> <I>%i - ",size);
fseek(in, 0x28, SEEK_SET);
key=fgetc(in)&0x07;
if(key<1) fprintf(out,"1.1 Honey</I></P>\n");
else if(key<2) fprintf(out,"1.2 Solitaire</I></P>\n");
else if(key<3) fprintf(out,"1.3 Kissy</I></P>\n");
else if(key<4) fprintf(out,"1.4 Goodnight</I></P>\n");
else if(key<5) fprintf(out,"2.1 Plenty</I></P>\n");
else if(key<6) fprintf(out,"2.2 Galore</I></P>\n");
else if(key<7) fprintf(out,"2.3 Domino</I></P>\n");
else if(key<8) fprintf(out,"2.4 Goodhead</I></P>\n");

count=0;
/*parse the actual code
grab command.  # commands given by +0x1.   multiply by size of commands*/
for(x=0xE4; x < end; count++)
{x+=4;
fseek(in, x, SEEK_SET);
fread(&suck,4,1,in);
if(suck==0) break;
fprintf(out,"\n<TABLE CELLSPACING=\"0\"><B>%08X </B>",byteswap(suck));

fseek(in, x+1, SEEK_SET);
fread(&com,1,1,in);
y=com*size;
fprintf(out,"<I>Size: %i</I>\n<TR>",com);
/*fprintf(out,"<TH>Check</TH>");*/

 for(com=1;com<=size;com++)
    {fprintf(out,"<TH>Controller %i</TH>",com);
    }
 fprintf(out,"</TR>\n",com);

 for(;y>0;y--)
              {x+=4;
/*binary output              fseek(in, x, SEEK_SET);
              fread(&suck,4,1,in);
              fprintf(out,"%08X%s",byteswap(suck), (y-1)%size ? " ":"\n");*/
              
              fseek(in, x, SEEK_SET);
              key=fgetc(in);
              fprintf(out,"%s%s%s",y%size ? "":"<TR",y%(2*size) ? "":" class=\"switch\"",y%size ? "":">");
/*              fprintf(out,"<TD>%08X%08X</TD>",checkHI,checkLO);*/
              fprintf(out,"<TD><IMG SRC=\"res/%s\"></IMG> %3d%% ",key<0 ? "SLT.png":"SRT.png", abs(key));
              key=fgetc(in);
              fprintf(out,"<IMG SRC=\"res/%s\"></IMG> %3d%% ",key<0 ? "SDN.png":"SUP.png", abs(key));
              key=fgetc(in);
              fprintf(out,"%s%s%s%s%s%s%s%s",key&0x01 ? "<IMG SRC=\"res/CLT.png\"></IMG>":"",key&0x02 ? "<IMG SRC=\"res/CRT.png\"></IMG>":"",key&0x04 ? "<IMG SRC=\"res/CDN.png\"></IMG>":"",key&0x08 ? "<IMG SRC=\"res/CUP.png\"></IMG>":"",key&0x10 ? "<IMG SRC=\"res/R.png\"></IMG>":"",key&0x20 ? "<IMG SRC=\"res/L.png\"></IMG>":"",key&0x40 ? "reserved1 ":"",key&0x80 ? "reserved2 ":"");
              key=fgetc(in);
              fprintf(out,"%s%s%s%s%s%s%s%s</TD>%s",key&0x01 ? "<IMG SRC=\"res/LT.png\"></IMG>":"",key&0x02 ? "<IMG SRC=\"res/RT.png\"></IMG>":"",key&0x04 ? "<IMG SRC=\"res/DN.png\"></IMG>":"",key&0x08 ? "<IMG SRC=\"res/UP.png\"></IMG>":"",key&0x10 ? "<IMG SRC=\"res/S.png\"></IMG>":"",key&0x20 ? "<IMG SRC=\"res/Z.png\"></IMG>":"",key&0x40 ? "<IMG SRC=\"res/B.png\"></IMG>":"",key&0x80 ? "<IMG SRC=\"res/A.png\"></IMG>":"",(y-1)%size ? "":"</TR>\n");
              /*this fiddles with the check value
              well, it should at any rate*/
              varA2=checkHI<<31;
              varA1=(checkLO>>1) | varA2;
              varA2=checkLO<<12;
              checkLO=varA2^varA1;
              varA2=(varA2>>20)&0xFFF;
              checkLO^=varA2;
              }
 fprintf(out,"\n</TABLE>\n");}
 
 /*wrap things up!*/
 fprintf(out,"\n<P><B>Final Count of Command Blocks:</B> <I>%X/%i</I>\n</BODY></HTML>",count,count);

fclose(in);
fclose(out);
return 0;}

/****************************************/
/*basic 32bit byteswap program*/
/****************************************/
unsigned long byteswap(unsigned long w)
{return (w >> 24) | ((w >> 8) & 0x0000ff00) | ((w << 8) & 0x00ff0000) | (w << 24);
}    
